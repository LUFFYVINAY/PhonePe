package com.example.phonepe;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

import com.example.phonepe.R;

public class BoardActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_board);
    }
}