package com.example.phonepe;

import android.app.Activity;

public class SecondFragment extends Activity {
}
